package mx.edu.utng.mlopez.oxxito2019;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import mx.edu.utng.mlopez.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.mlopez.oxxito2019.model.Producto;

public class GestionProducto extends AppCompatActivity {

    private EditText txtCodigo;
    private EditText txtNombre;
    private EditText txtPrecio;
    private EditText txtExistencias;
    private EditText txtFechaCaducidad;
    private Button btnActuaizar;
    private Button btnCancelar;
    private Button btnEliminar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_producto);
        //Se relaciona el XML con la clase JAVA
        txtCodigo = (EditText) findViewById(R.id.txt_codigo3);
        txtNombre = (EditText) findViewById(R.id.txt_nombreProducto3);
        txtPrecio = (EditText) findViewById(R.id.txt_precio3);
        txtExistencias = (EditText) findViewById(R.id.txt_existencias3);
        txtFechaCaducidad = (EditText) findViewById(R.id.txt_fechaCaducidad3);

        btnActuaizar = (Button) findViewById(R.id.btn_actualizar);
        btnCancelar = (Button) findViewById(R.id.btn_cancelar);
        btnEliminar = (Button) findViewById(R.id.btn_eliminar);
        //Obtener el valor CODIGO_DE_BARRAS de un bundle de la actividad
        String codigo = getIntent().getExtras().getString("codigo");
        // Se emplea un objeto producto
        Producto p = new Producto();
        //Se asigna el codigo de barras al objeto Producto
        p.setCodigo(codigo);
        //Se crea un objeto DAO para buscar el producto
        ProductoDAO dao = new ProductoDAO(getApplicationContext());
        try {
            p = dao.getById(p);
            //En caso de exito asignamos los valores a los conroles
            txtCodigo.setText(p.getCodigo());
            txtNombre.setText(p.getNombre());
            txtPrecio.setText("" + p.getPrecio());
            txtExistencias.setText("" + p.getExistencias());
            txtFechaCaducidad.setText(p.getFechaCaducidad());
        } catch (Exception e) {
            //En caso de error
            Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        //Se agrega un escuchador de eventos al boton btnActualizar
        btnActuaizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Crear objeto Producto
                Producto p = new Producto();
                //Se asignan los datos a los atributos de objeto
                p.setCodigo(txtCodigo.getText().toString());
                p.setNombre(txtNombre.getText().toString());
                p.setPrecio(Double.parseDouble(txtPrecio.getText().toString()));
                p.setExistencias(Integer.parseInt(txtExistencias.getText().toString()));
                p.setFechaCaducidad(txtFechaCaducidad.getText().toString());
                //Se crea un objeto DAO para almacenar al objeto
                ProductoDAO dao = new ProductoDAO(getApplicationContext());
                //Se intenta realizar los cambios
                try {
                    dao.update(p);
                    Toast.makeText(getApplicationContext(), "Producto actualizado!", Toast.LENGTH_SHORT).show();
                    //Se cierra el activity
                    System.exit(0);
                } catch (Exception e) {
                    //Se manda mensaje en caso de error
                    Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        //Se agrega un escuchador de eventos al boton btnEliminar
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Se crea un objeto Producto
                Producto p = new Producto();
                //Se asignan sus atributos
                p.setCodigo(txtCodigo.getText().toString());
                //Se crea un objeto DAO
                ProductoDAO dao = new ProductoDAO(getApplicationContext());
                //Se intenta eliminar el objeto
                try {
                    dao.delete(p);
                    //Mensaje de exito
                    Toast.makeText(getApplicationContext(), "Producto Eliminado!", Toast.LENGTH_LONG).show();
                    //Se cierra el activity
                    System.exit(0);
                } catch (Exception e) {
                    //Se manda mensaje en caso de error
                    Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        //Se asigna un escuchador al botob btnCancelar
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Se cierra la vista
                System.exit(0);
            }
        });
    }
}/*End*/