package mx.edu.utng.mlopez.oxxito2019.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Conexion {

    //Definir la varieble context, apartir de esta se crea la BD.
    private Context contexto;

    public Conexion(Context contexto){
        this.contexto = contexto;
    }

    /**
     *
     * Método para abrir la conexión a la base de datos
     */
    private SQLiteDatabase abrirConexion(){
        //Se crea un objeto SQLiteDATABASE.
        SQLiteDatabase conexion = contexto.openOrCreateDatabase(
                "oxxito.db", //Nombre
                SQLiteDatabase.OPEN_READWRITE, //Modo de lectura
                null); //Factory para la BD
        return conexion;
    }

    /**
     *
     * Método para cerrar la conexión a la base de datos.
     */
    private void cerrarConexion(SQLiteDatabase conexion){
        if(conexion!=null){
            conexion.close();
        }
    }

    /**
     *
     * Método para ejecutar sentencias de SQL (Insert, Update, Delete).
     */
    public boolean ejecutarSentencias(String sentencia) throws Exception{
        //Se debe abrir la conexión
        SQLiteDatabase conexion = abrirConexion();
        try {
            //Se ejecuta la sentencia sobre la conexión
            conexion.execSQL(sentencia);
            //Se cierra la conexión
            conexion.close();
        }catch(Exception e) {
                //Se lanza la excepción al método que la invoque
                throw new Exception("Error en la sentencia: "+ e.getMessage());
        }
        return true;
    }

    public List<HashMap<String,String>> ejecutarConsulta(String tabla,
                                                         String[] campos,
                                                         String condicion) throws Exception{
        //Se crea una lista de objectos HashMap, donde cada HashMap representará un objeto de la BD.
        List<HashMap<String, String>> datos = new ArrayList<HashMap<String, String>>();
        try {
            //Se abre la conexión
            SQLiteDatabase conexion = abrirConexion();
            //Se cosulta la BD, de acuerdo a los parametros señalados
            Cursor resultado = conexion.query(tabla, campos, condicion,
                    null,null,
                    null,null);
            HashMap<String, String> registro;
            //Se itera por cada uno de los registroa alojados por la consuta
            while(resultado.moveToNext()){
                //Para cada registro en la BD, se crea un HashMap
                registro = new HashMap<String, String>();
                for(int i=0;i<campos.length;i++){
                    registro.put(campos[i],resultado.getString(i));
                }
                //Agregamos el reistro a la loista
                datos.add(registro);
            }
            //Se cierra la conexión
            conexion.close();
        }catch(Exception e) {
            //Lanzamos la Excepción
            throw new Exception("Error al ejecutar la consulta:" + e.getMessage());
        }
        //En caso de exito retorna el resultado de la consulta
        return datos;
    }

    /**
     * Método para inicializar (crear la estructura) de la BD.
     */
    public void inicializarBD() throws Exception{
        //Se bre la conexión a la BD
        SQLiteDatabase conexion = abrirConexion();
        //Se ejecuta una sentencia para borrar la tabla de productos, em caso de existir
        conexion.execSQL("DROP TABLE IF EXISTS PRODUCTOS");
        //Se ejecuta la sentencia para crear la tabla de productos.
        conexion.execSQL("CREATE TABLE PRODUCTOS(codigo TEXT," +
                "nombre TEXT, precio REAL, existencias INTEGER," +
                "fechaCaducidad TEXT)");
        //Se cierra la tabla
        conexion.close();
    }
}/*End*/