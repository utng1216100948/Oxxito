package mx.edu.utng.mlopez.oxxito2019;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import mx.edu.utng.mlopez.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.mlopez.oxxito2019.model.Producto;

public class NuevoProducto extends AppCompatActivity {

    private EditText txtCodigo;
    private EditText txtNombre;
    private EditText txtPrecio;
    private EditText txtExistencias;
    private EditText txtFechaCaducidad;
    private Button btnGuardar;
    private Button btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_producto);
        //Inflate
        txtCodigo = (EditText)findViewById(R.id.txt_codigo);
        txtNombre = (EditText)findViewById(R.id.txt_producto);
        txtPrecio = (EditText)findViewById(R.id.txt_precio);
        txtExistencias = (EditText)findViewById(R.id.txt_existencias);
        txtFechaCaducidad = (EditText)findViewById(R.id.txt_fechaCaducidad);
        btnGuardar = (Button)findViewById(R.id.btn_guardar);
        btnCancelar = (Button)findViewById(R.id.btn_cancelar);

        //Se asigna un escuchador al btnGuardar
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Se crea un ojeto Producto
                Producto p = new Producto();
                //Se asignan los atributo
                p.setCodigo(txtCodigo.getText().toString());
                p.setNombre(txtNombre.getText().toString());
                p.setPrecio(Double.parseDouble(txtPrecio.getText().toString()));
                p.setExistencias(Integer.parseInt(txtExistencias.getText().toString()));
                p.setFechaCaducidad(txtFechaCaducidad.getText().toString());
                //Se crea un objeto DAO
                ProductoDAO dao = new ProductoDAO(getApplicationContext());
                //Se intenta insertar e objeto
                try {
                    dao.insertar(p);
                    //Se manda mensaje de exito
                    Toast.makeText(getApplicationContext(), "Producto guardado!", Toast.LENGTH_SHORT).show();
                    //Se cierra el activity
                    System.exit(0);
                }catch(Exception e) {
                    //Se muestra mensaje de error
                    Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
                    //Se cierra el activity
                    System.exit(0);
                }
                limpiarRegistro();
            }
        });
        //Se agrega escuchador al boton btnCancelar
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limpiarRegistro();
                Toast.makeText(getApplicationContext(), "Cancelando..", Toast.LENGTH_LONG).show();
                //Se cierra el activity
                System.exit(0);
            }
        });
    }

    public void limpiarRegistro(){
        txtCodigo.setText("");
        txtPrecio.setText("");
        txtExistencias.setText("");
        txtFechaCaducidad.setText("");
    }
}/*End*/