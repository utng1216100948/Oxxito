package mx.edu.utng.mlopez.oxxito2019;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.mlopez.oxxito2019.dao.ProductoDAO;
import mx.edu.utng.mlopez.oxxito2019.model.Producto;

public class ListaProductos extends AppCompatActivity {

    private Button btnNuevo;
    private ListView lsvProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos);
        //Inflate
        btnNuevo = (Button) findViewById(R.id.btn_agregarProducto);
        lsvProductos = (ListView) findViewById(R.id.lsv_productos);
        //Se agrega escuchador al boton btnNuevo
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Se crea intento para iniciar actividad
                Intent intNuevoProducto = new Intent(getApplicationContext(), NuevoProducto.class);
                //Se arranca la actividad
                startActivity(intNuevoProducto);
            }
        });
        //Se crea un objeto DAO para consultar todos los productos
        ProductoDAO dao = new ProductoDAO(getApplicationContext());
        //Se crea un objeto para la lista de productos y se obtiene la lista
        List<Producto> listaProductos;
        try {
            //Se realiza la consulta
            listaProductos = dao.getAll();
            //Se crea un objeto hashMap para cada registro
            List<HashMap<String, String>> filas = new ArrayList<HashMap<String, String>>();
            HashMap<String,String> registro;
            for(Producto prod: listaProductos) {
                registro = new HashMap<String, String>();
                registro.put("codigo", prod.getCodigo());
                registro.put("nombre", prod.getNombre());
                registro.put("precio", String.valueOf(prod.getPrecio()));
                registro.put("existencias", String.valueOf(prod.getExistencias()));
                registro.put("fechaCaducidad", String.valueOf(prod.getFechaCaducidad()));

                filas.add(registro);
            }
            //Se crea un adaptador para visualizar el registro de la lista
            SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(),filas, R.layout.activity_registro_producto,new String[]{"codigo",
            "nombre","precio","existencias","fechaCaducidad"}, new int[]{R.id.txt_codigo2, R.id.txt_producto2, R.id.txt_precio2, R.id.txt_existencias, R.id.txt_fechaCaducidad2});
            //Se asigna el adaptador a la vista
            lsvProductos.setAdapter(adapter);

            //Se genera un escuchador de eventos para los items del ListView
            lsvProductos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    //Se obtiene el control que obtiene el código de barras del elemento seleccionado
                    TextView txtCodigo = (TextView)arg1.findViewById(R.id.txt_codigo2);
                    //Se crea el objeto Bundle
                    Bundle bundle = new Bundle();
                    //Se inserta el código en el objeto bundle
                    bundle.putString("codigo",txtCodigo.getText().toString());
                    //Se crea un objeto bundle para iniciar la actividad
                    Intent intGestionProducto = new Intent(getApplicationContext(), GestionProducto.class);
                    //Se inserta el bundle en el intent
                    intGestionProducto.putExtras(bundle);
                    //Se inicia la actividad
                    startActivity(intGestionProducto);
                }
            });
        }catch(Exception e) {
            Toast.makeText(getApplicationContext(), "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}/*End*/