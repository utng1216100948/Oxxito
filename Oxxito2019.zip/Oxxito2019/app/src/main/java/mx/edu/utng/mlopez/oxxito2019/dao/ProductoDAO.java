package mx.edu.utng.mlopez.oxxito2019.dao;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.edu.utng.mlopez.oxxito2019.model.Producto;

public class ProductoDAO {
    private Context context;

    public ProductoDAO(Context context){
        this.context= context;
    }

    public void insertar(Producto obj) throws Exception{
        String comando = "INSERT INTO PRODUCTOS(codigo, nombre, precio, existencias, fechaCaducidad) " +
                "VALUES ('" + obj.getCodigo()+"','"+obj.getNombre()+"',"+obj.getPrecio()+ ","+ obj.getExistencias()+",'"+ obj.getFechaCaducidad()+"')";

        Conexion con= new Conexion(context);
        try{
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw  new Exception("Error al insertar: "+ e.getMessage());
        }
    }

    public void update(Producto obj) throws Exception{
        String comando = "UPDATE PRODUCTOS SET nombre='"+obj.getNombre()+ "', "+ "precio="+ obj.getPrecio()+", "+ "existencias="+ obj.getExistencias()+", "+ "fechaCaducidad='"+obj.getFechaCaducidad()+"' "+ " WHERE codigo='"+ obj.getCodigo()+"'";

        Conexion con = new Conexion(context);

        try {
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw  new Exception("Errot al actualizar: "+ e.getMessage());
        }
    }

    public void delete(Producto obj) throws  Exception{
        String comando= "DELETE FROM PRODUCTOS WHERE codigo='"+ obj.getCodigo()+ "'";
        Conexion con= new Conexion(context);

        try {
            con.ejecutarSentencias(comando);
        }catch (Exception e){
            throw new Exception("Error al eliminar: "+ e.getMessage());
        }
    }
    public List<Producto> getAll() throws Exception{
        String tabla ="PRODUCTOS";
        String campos [] = new String[]{ "codigo", "nombre", "precio", "existencias", "fechaCaducidad"};

        List<Producto> listaProductos= new ArrayList<Producto>();
        Conexion con = new Conexion(context);

        List<HashMap<String,String>> resultado;
        resultado= con.ejecutarConsulta(tabla, campos, null);

        Producto producto;

        for (HashMap<String, String> reg: resultado){
            producto = new Producto();

            producto.setCodigo(reg.get("codigo"));
            producto.setNombre(reg.get("nombre"));
            producto.setPrecio(Double.valueOf(reg.get("precio")));
            producto.setExistencias(Integer.valueOf(reg.get("existencias")));
            producto.setFechaCaducidad(reg.get("fechaCaducidad"));

            listaProductos.add(producto);

        }
        return listaProductos;
    }

    public Producto getById(Producto obj) throws Exception{
        String tabla = "PRODUCTOS";
        String campos[] = new String[]{"codigo", "nombre", "precio", "existencias", "fechaCaducidad"};

        String condicion= "codigo='"+ obj.getCodigo()+"'";

        Conexion con = new Conexion(context);

        List<HashMap<String,String>> resultado;

        resultado= con.ejecutarConsulta(tabla, campos, condicion);

        Producto producto= null;

        for (HashMap<String, String> reg: resultado){
            producto = new Producto();

            producto.setCodigo(reg.get("codigo"));
            producto.setNombre(reg.get("nombre"));
            producto.setPrecio(Double.valueOf(reg.get("precio")));
            producto.setExistencias(Integer.valueOf(reg.get("existencias")));
            producto.setFechaCaducidad(reg.get("fechaCaducidad"));

        }

        return producto;

    }
}/* End */